
double get_sum(double a,double b)
{
  return (a+b);
}
 

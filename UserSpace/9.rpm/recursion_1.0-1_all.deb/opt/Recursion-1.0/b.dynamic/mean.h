double get_mean(double,double);
